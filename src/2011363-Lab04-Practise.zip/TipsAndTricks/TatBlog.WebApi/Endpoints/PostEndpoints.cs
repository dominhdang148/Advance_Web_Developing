﻿namespace TatBlog.WebApi.Endpoints
{
    public class PostEndpoints
    {

    }
}
