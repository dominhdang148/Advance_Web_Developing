const Index=()=>{
    return(
        <>
            <h1>Đây là khu vực dành cho người quản trị</h1>
        </>
    );
}

export default Index;