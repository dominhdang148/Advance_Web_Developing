﻿namespace TatBlog.WebApi.Models
{
    public class TagDto
    {
        public int Id { get; set; }
        public string Name { get;set; }
        public string UrlSlug { get; set; }
    }
}
