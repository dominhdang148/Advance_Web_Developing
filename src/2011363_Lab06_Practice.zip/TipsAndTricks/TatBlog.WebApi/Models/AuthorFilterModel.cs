﻿namespace TatBlog.WebApi.Models
{
    public class AuthorFilterModel : PagingModel
    {
        public string Name { get; set; }    
    }
}
